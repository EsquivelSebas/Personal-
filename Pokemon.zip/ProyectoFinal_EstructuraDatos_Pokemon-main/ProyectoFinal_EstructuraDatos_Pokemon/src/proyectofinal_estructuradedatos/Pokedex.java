/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal_estructuradedatos;

/**
 *
 * @author Raquel Vargas
 */
public class Pokedex {
    private NodoP cabeza;
    
    public void agregarPokemon(Pokemon p){
        if(contarNodos() <= 3){
            if(cabeza == null){ 
                cabeza = new NodoP(p);
            } else if (p.getId() < cabeza.getPokemon().getId()){ 
                NodoP aux = new NodoP(p); 
                aux.setNext(cabeza); 
                cabeza = aux;          
            } else if (cabeza.getNext() == null){
                cabeza.setNext(new NodoP(p));
            } else {
                NodoP aux = cabeza;
                while(aux.getNext()!= null && aux.getNext().getPokemon().getId() < p.getId()){
                    aux = aux.getNext();
                }
                NodoP temp = new NodoP(p);
                temp.setNext(aux.getNext());
                aux.setNext(temp);
            }
        }else{
            System.out.println("Pokedex lleno");
        }
    }
    
    public Pokemon extraePokemon(int id){//Este metodo extrae a los pokemon que quedan sin vida
        Pokemon p = null;
        if(cabeza != null){
            if(cabeza.getPokemon().getId() == id){
                p = cabeza.getPokemon();
                cabeza = cabeza.getNext();
            }else{
                NodoP aux = cabeza;
                while (aux.getNext() != null && aux.getNext().getPokemon().getId() < id){
                    aux = aux.getNext();
                }
                
                if(aux.getNext() != null && aux.getNext().getPokemon().getId() == id){
                    p = aux.getNext().getPokemon();
                    aux.setNext(aux.getNext().getNext());
                }
            }
        }
        
        return p;
    }
    
    public int contarNodos() {
        int contador = 0;
        NodoP aux = cabeza;
        while (aux != null) {
            contador++;
            aux = aux.getNext();
        }
        return contador;
    }
    
    @Override
    public String toString() {
        NodoP aux = cabeza;
        String s = "Pokedex: ";
        while (aux != null){
            s += aux + "\n";
            aux = aux.getNext();
        }
        return s;
    }
}