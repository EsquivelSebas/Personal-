package proyectofinal_estructuradedatos;

/**
 *
 * @author sfallas
 */
public enum TipoPokemon {
    FUEGO, AGUA, NORMAL 
}
