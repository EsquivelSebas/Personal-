package proyectofinal_estructuradedatos;

/**
 *
 * @author sfallas
 */
public class Pokemon {
    private int id;
    private TipoPokemon tipo;
    private int Nivel;
    private int Evolucion; //se debe definir un numero para evolucionar a cada pokemon
    private String nombre;
    private TipoPokemon[] fuertesContra;
    private TipoPokemon[] debilesContra;
    private int vida;
    private int ataque;
    private int defensa;
    private int ataqueEspecial;
    private int defensaEspecial;

    public Pokemon(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Pokemon(int id, TipoPokemon tipo, int Nivel, int Evolucion, String Nombre, TipoPokemon[] fuertesContra, TipoPokemon[] debilesContra, int vida, int ataque, int defensa, int ataqueEspecial, int defensaEspecial) {
        this.id = id;
        this.tipo = tipo;
        this.Nivel = Nivel;
        this.Evolucion = Evolucion;
        this.nombre = Nombre;
        this.fuertesContra = fuertesContra;
        this.debilesContra = debilesContra;
        this.vida = vida;
        this.ataque = ataque;
        this.defensa = defensa;
        this.ataqueEspecial = ataqueEspecial;
        this.defensaEspecial = defensaEspecial;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public TipoPokemon getTipo() {
        return tipo;
    }

    public void setTipo(TipoPokemon tipo) {
        this.tipo = tipo;
    }

    public TipoPokemon[] getFuertesContra() {
        return fuertesContra;
    }

    public void setFuertesContra(TipoPokemon[] fuertesContra) {
        this.fuertesContra = fuertesContra;
    }

    public TipoPokemon[] getDebilesContra() {
        return debilesContra;
    }

    public void setDebilesContra(TipoPokemon[] debilesContra) {
        this.debilesContra = debilesContra;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }

    public int getAtaqueEspecial() {
        return ataqueEspecial;
    }

    public void setAtaqueEspecial(int ataqueEspecial) {
        this.ataqueEspecial = ataqueEspecial;
    }

    public int getDefensaEspecial() {
        return defensaEspecial;
    }

    public void setDefensaEspecial(int defensaEspecial) {
        this.defensaEspecial = defensaEspecial;
    }

    public int getNivel() {
        return Nivel;
    }

    public void setNivel(int Nivel) {
        this.Nivel = Nivel;
    }

    public int getEvolucion() {
        return Evolucion;
    }

    public void setEvolucion(int Evolucion) {
        this.Evolucion = Evolucion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }
    
    public void modificarVida(int ataqueRecibido){
        if(ataqueRecibido != 0){
            this.vida -= ataqueRecibido;
        }
        
        if (this.vida < 0) {
            this.vida = 0;
            //Mostrar mensaje por pantalla al jugador 
            System.out.println("Vida del pokemon en 0");
        }
    }
    
}
