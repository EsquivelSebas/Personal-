package proyectofinal_estructuradedatos;

/**
 *
 * @author sfallas
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PokemonAgua agua = new PokemonAgua(1,"agua");
        PokemonFuego fuego = new PokemonFuego(2,"fuego");
        PokemonNormal normal = new PokemonNormal(2,"normal");
        
        //Probando Pokemon de Agua
        System.out.println("Pokemon AGUA");
        System.out.println("Vida Inicial " + agua.getVida());
        agua.atacar();//Supongamos que el usuario seleccionó acción de atacar
        agua.atacarEspecial(TipoPokemon.AGUA);//Supongamos que el usuario seleccionó acción de ataque especial contra un pokemon agua
        agua.atacarEspecial(TipoPokemon.NORMAL);//Supongamos que el usuario seleccionó acción de ataque especial contra un pokemon Normal
        
        agua.defenderse(70);//Supongamos que el usuario recibe ataque de un pokemon de fuego
        System.out.println("Vida despues del ataque recibido de pokemon de fuego " + agua.getVida());
        agua.defenderseEspecial(TipoPokemon.FUEGO, 80);//Supongamos que el usuario recibe ataque especial de un pokemon de fuego
        System.out.println("Vida despues del ataque especial recibido de pokemon de fuego " + agua.getVida());
        agua.defenderseEspecial(TipoPokemon.NORMAL, 50);//Supongamos que el usuario recibe ataque de un pokemon de normal
        System.out.println("Vida despues del ataque especial recibido de pokemon de normal " + agua.getVida());
        
        //Probando Pokemon de FUEGO
        System.out.println("\n\nPokemon FUEGO");
        System.out.println("Vida Inicial " + fuego.getVida());
        fuego.atacar();//Supongamos que el usuario seleccionó acción de atacar
        fuego.atacarEspecial(TipoPokemon.AGUA);//Supongamos que el usuario seleccionó acción de ataque especial contra un pokemon fuego
        fuego.atacarEspecial(TipoPokemon.NORMAL);//Supongamos que el usuario seleccionó acción de ataque especial contra un pokemon Normal
        
        fuego.defenderse(70);//Supongamos que el usuario recibe ataque de un pokemon de fuego
        System.out.println("Vida despues del ataque recibido de pokemon de fuego " + fuego.getVida());
        fuego.defenderseEspecial(TipoPokemon.FUEGO, 80);//Supongamos que el usuario recibe ataque especial de un pokemon de fuego
        System.out.println("Vida despues del ataque especial recibido de pokemon de fuego " + fuego.getVida());
        fuego.defenderseEspecial(TipoPokemon.NORMAL, 70);//Supongamos que el usuario recibe ataque de un pokemon de normal
        System.out.println("Vida despues del ataque especial recibido de pokemon de normal " + fuego.getVida());
    
        //Manejo de jugadores
        Pokedex pokedexJugador = new Pokedex();
        Pokedex pokedexCPU = new Pokedex();
        Jugador jugador = new Jugador("Jugador 1", "Jugador", pokedexJugador);
        Jugador oponenteCpu = new Jugador("Jugador CPU", "CPU", pokedexCPU);//Al ser tipo CPU no debe dejar poner un nombre
        
        //Suponemos que el jugador selecciona los pokemon
        jugador.llenarPokedex(fuego);
        jugador.llenarPokedex(agua);
        jugador.llenarPokedex(normal);
        jugador.llenarPokedex(fuego);//No deberia ingresar
        
        System.out.println("Nombre jugador: " + jugador.getNombre());
        System.out.println("Pokedex de " + jugador.getNombre() + ":\n" + jugador.getPokedex());
        
    }
    
}
