/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal_estructuradedatos;

/**
 *
 * @author Raquel Vargas 
 */
public class NodoP {//clase nodo del Pokedex
    private Pokemon pokemon;
    private NodoP next; 
    
    public NodoP(Pokemon pokemon) {
        this.pokemon = pokemon;
    }

    public Pokemon getPokemon() {
        return pokemon;
    }

    public void setPokemon(Pokemon pokemon) {
        this.pokemon = pokemon;
    }

    public NodoP getNext() {
        return next;
    }

    public void setNext(NodoP next) {
        this.next = next;
    }

    @Override
    public String toString() {
        return "Pokemon: " + pokemon;
    }
}
