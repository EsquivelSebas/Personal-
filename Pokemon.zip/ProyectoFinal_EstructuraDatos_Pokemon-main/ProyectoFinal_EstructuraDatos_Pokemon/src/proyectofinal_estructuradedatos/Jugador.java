/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal_estructuradedatos;
/**
 *
 * @author Raquel Vargas
 */
public class Jugador {
    private String nombre;
    private String tipoJugador;
    private int cantBatallas;
    private int cantBatallasGanadas;
    private Pokemon pokemonSeleccionado;//Este será el Pokemon que el jugador seleccione durante las batallas
    private Pokedex pokedex;//Clase que a futuro se construirá para almacenar los Pokemon seleccionados

    public Jugador(String nombre, String tipoJugador, Pokedex pokedex) {
        this.nombre = nombre;
        this.tipoJugador = tipoJugador;
        this.pokedex = pokedex;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantBatallas() {
        return cantBatallas;
    }

    public void setCantBatallas(int cantBatallas) {
        this.cantBatallas = cantBatallas;
    }

    public int getCantBatallasGanadas() {
        return cantBatallasGanadas;
    }

    public void setCantBatallasGanadas(int cantBatallasGanadas) {
        this.cantBatallasGanadas = cantBatallasGanadas;
    }

    public Pokemon getPokemonSeleccionado() {
        return pokemonSeleccionado;
    }

    public void setPokemonSeleccionado(Pokemon pokemonSeleccionado) {
        this.pokemonSeleccionado = pokemonSeleccionado;
    }

    public String getTipoJugador() {
        return tipoJugador;
    }

    public void setTipoJugador(String tipoJugador) {
        this.tipoJugador = tipoJugador;
    }
    
    public Pokedex getPokedex() {
        return pokedex;
    }
    
    //Método para llenar el Pokedex
    public Pokedex llenarPokedex(Pokemon pokemon){
        pokedex.agregarPokemon(pokemon);
        return pokedex;
    }
    
    //Método para seleccionar el Pokemon que desea
    public void seleccionarPokemon(){
    
    }
    
    public void NombreJugador(String nombre, String tipoJugador){
        if(tipoJugador.equals("CPU")){
            setNombre("Oponente(CPU)");
        }else{
            setNombre(nombre);
        }
    }
}