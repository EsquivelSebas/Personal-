/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal_estructuradedatos;

/**
 *
 * @author Raquel Vargas
 */
public class PokemonFuego extends Pokemon{
    
    public PokemonFuego(int id,String nombre) {
        super(id,nombre);
        setTipo(TipoPokemon.FUEGO);
        setVida(115);
        setAtaque(70);
        setDefensa(45);
        setAtaqueEspecial(80);
        setDefensaEspecial(60);
    }
    
    public int atacar(){ // este metodo solo retorna la cantidad numerica de ataque del pokemon
                        // esto es porque el metodo de defensa de los pokemon recibe un ataque por parametro
        int ataque;
        int ataqueFallido = (int) (Math.random() * 2);// tomaremos un 1 como un true y un 0 como false
        if(ataqueFallido == 0){
            ataque = getAtaque();
            //Se muestra al usuario que envio un ataque al oponente
            System.out.println("Ataque: " + ataque);
        }else{
            ataque = 0;
            //Se muestra al usuario que envio un ataque al oponente
            System.out.println("Ataque fallido");
        }
        return ataque;
    }
    
    public void defenderse(int ataqueRecibido){
        int ataqueFinal = 0;
        //Se calcula cuanta vida pierde el pokemon cuando se defiende
        if(ataqueRecibido < getDefensa()){
            System.out.println("Ataque bloqueado");
        }else{
            ataqueFinal = ataqueRecibido - getDefensa();
            //Se muestra al usuario el ataque recibido
            modificarVida(ataqueFinal);
        }
    }
    
    public int atacarEspecial(TipoPokemon tipoOponente){
        int ataque;
        
        //Ataque especial de 75 HP, aumenta hasta 85 HP contra tipo Fuego.
        if(tipoOponente == TipoPokemon.NORMAL){
            ataque = 85;
            //Se muestra al usuario que envio un ataque especial al oponente
            System.out.println("Ataque especial: " + ataque);
        }else{
            ataque = getAtaqueEspecial();
            //Se muestra al usuario que envio un ataque especial al oponente
            System.out.println("Ataque especial: " + ataque);
        }
        return ataque;
    }
    
    public void defenderseEspecial(TipoPokemon tipoOponente, int ataqueRecibido){
        int ataqueFinal = 0;
        int defensa = getDefensaEspecial();
        //Defensa especial de 65 HP, aumenta hasta 75 HP contra tipo Fuego.
        if(tipoOponente == TipoPokemon.NORMAL){
            defensa = 70;
        }
        
        if(ataqueRecibido < defensa){
            System.out.println("Ataque bloqueado con defensa especial");
        }else{
            ataqueFinal = ataqueRecibido - defensa;
            //Se muestra al usuario el ataque recibido (cuando se implemente interfaz)
            modificarVida(ataqueFinal);
        }
    }
    
}
