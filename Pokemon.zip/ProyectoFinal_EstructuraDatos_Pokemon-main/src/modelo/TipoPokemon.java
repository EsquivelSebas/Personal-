package modelo;

public enum TipoPokemon {
    FUEGO, AGUA, NORMAL
}
