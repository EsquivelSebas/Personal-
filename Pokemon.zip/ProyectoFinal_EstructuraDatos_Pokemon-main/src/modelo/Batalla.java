package modelo;

import static modelo.TipoPokemon.AGUA;
import static modelo.TipoPokemon.FUEGO;
import static modelo.TipoPokemon.NORMAL;

public class Batalla {

    private Entrenador entrenador1;
    private Entrenador entrenador2;
    private int numeroBatalla;

    public Batalla(Entrenador entrenador1, Entrenador entrenador2, int numeroBatalla) {
        this.entrenador1 = entrenador1;
        this.entrenador2 = entrenador2;
        this.numeroBatalla = numeroBatalla;
    }

    public int atacar(Pokemon pokemonEntrenador1, Pokemon pokemonEntrenador2) {
        TipoPokemon tipoPokemon = pokemonEntrenador1.getTipo();
        int valorAtaque = 0;

        switch (tipoPokemon) {
            case AGUA: {
                PokemonAgua pokemonAgua = (PokemonAgua) pokemonEntrenador1;

                valorAtaque = pokemonAgua.atacar();
            }
            break;
            case NORMAL: {
                PokemonNormal pokemonNormal = (PokemonNormal) pokemonEntrenador1;
                valorAtaque = pokemonNormal.atacar();
            }
            break;
            case FUEGO: {
                PokemonFuego pokemonFuego = (PokemonFuego) pokemonEntrenador1;
                valorAtaque = pokemonFuego.atacar();
            }
            break;
        }

        return valorAtaque;
    }

    public int atacarEspecial(Pokemon pokemonEntrenador1, Pokemon pokemonEntrenador2) {
        TipoPokemon tipoPokemon = pokemonEntrenador1.getTipo();
        int valorAtaque = 0;

        switch (tipoPokemon) {
            case AGUA: {
                PokemonAgua pokemonAgua = (PokemonAgua) pokemonEntrenador1;

                valorAtaque = pokemonAgua.atacarEspecial(pokemonEntrenador2.getTipo());
            }
            break;
            case NORMAL: {
                PokemonNormal pokemonNormal = (PokemonNormal) pokemonEntrenador1;
                valorAtaque = pokemonNormal.atacarEspecial(pokemonEntrenador2.getTipo());
            }
            break;
            case FUEGO: {
                PokemonFuego pokemonFuego = (PokemonFuego) pokemonEntrenador1;
                valorAtaque = pokemonFuego.atacarEspecial(pokemonEntrenador2.getTipo());
            }
            break;
        }

        return valorAtaque;
    }

    public int realizarMovimientoAleatorioCPU(Pokemon pokemonCPU1, Pokemon pokemonEntrenador1, int valorAtaqueEntrenador1) {
        int valorAtaque = 0;
        // tomaremos un 1 como un true y un 0 como false
        int movimientoAleatorio = (int) (Math.random() * 4);

        switch (movimientoAleatorio) {
            case 0: { // Defensa
                switch (pokemonCPU1.getTipo()) {
                    case AGUA: {
                        PokemonAgua pokemonAgua = (PokemonAgua) pokemonCPU1;
                        valorAtaque = pokemonAgua.defenderse(valorAtaqueEntrenador1);
                    }
                    break;
                    case NORMAL: {
                        PokemonNormal pokemonNormal = (PokemonNormal) pokemonCPU1;
                        valorAtaque = pokemonNormal.defenderse(valorAtaqueEntrenador1);
                    }
                    break;
                    case FUEGO: {
                        PokemonFuego pokemonFuego = (PokemonFuego) pokemonCPU1;
                        valorAtaque = pokemonFuego.defenderse(valorAtaqueEntrenador1);
                    }
                    break;
                }
            }
            break;
            case 1: { // Ataque
                valorAtaque = valorAtaqueEntrenador1;
                pokemonCPU1.modificarVida(valorAtaqueEntrenador1);

                if (pokemonCPU1.estaConVida()) {
                    valorAtaque = atacar(pokemonCPU1, pokemonEntrenador1);
                    pokemonEntrenador1.modificarVida(valorAtaque);
                }
            }
            break;
            case 2: { // Defensa Especial
                switch (pokemonCPU1.getTipo()) {
                    case AGUA: {
                        PokemonAgua pokemonAgua = (PokemonAgua) pokemonCPU1;
                        valorAtaque = pokemonAgua.defenderseEspecial(pokemonEntrenador1.getTipo(), valorAtaqueEntrenador1);
                    }
                    break;
                    case NORMAL: {
                        PokemonNormal pokemonNormal = (PokemonNormal) pokemonCPU1;
                        valorAtaque = pokemonNormal.defenderseEspecial(pokemonEntrenador1.getTipo(), valorAtaqueEntrenador1);
                    }
                    break;
                    case FUEGO: {
                        PokemonFuego pokemonFuego = (PokemonFuego) pokemonCPU1;
                        valorAtaque = pokemonFuego.defenderseEspecial(pokemonEntrenador1.getTipo(), valorAtaqueEntrenador1);
                    }
                    break;
                }
            }
            break;
            case 3: { // Ataque Especial
                valorAtaque = valorAtaqueEntrenador1;
                pokemonCPU1.modificarVida(valorAtaqueEntrenador1);

                if (pokemonCPU1.estaConVida()) {
                    valorAtaque = atacarEspecial(pokemonCPU1, pokemonEntrenador1);
                    pokemonEntrenador1.modificarVida(valorAtaque);
                }
                
            }
            break;
        }
        
        return valorAtaque;
    }

    public Entrenador getEntrenador1() {
        return entrenador1;
    }

    public Entrenador getEntrenador2() {
        return entrenador2;
    }

    public int getNumeroBatalla() {
        return numeroBatalla;
    }
}
