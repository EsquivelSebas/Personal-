package modelo;

public class Jugador {

    private String nombre;
    private int cantBatallas;
    private int cantBatallasGanadas;
    private Pokemon pokemonSeleccionado;//Este será el Pokemon que el jugador seleccione durante las batallas
    private Pokedex pokedex;//Clase que a futuro se construirá para almacenar los Pokemon seleccionados

    public Jugador(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantBatallas() {
        return cantBatallas;
    }

    public void setCantBatallas(int cantBatallas) {
        this.cantBatallas = cantBatallas;
    }

    public int getCantBatallasGanadas() {
        return cantBatallasGanadas;
    }

    public void setCantBatallasGanadas(int cantBatallasGanadas) {
        this.cantBatallasGanadas = cantBatallasGanadas;
    }

    public Pokemon getPokemonSeleccionado() {
        return pokemonSeleccionado;
    }

    public void setPokemonSeleccionado(Pokemon pokemonSeleccionado) {
        this.pokemonSeleccionado = pokemonSeleccionado;
    }

    //Método para llenar el Pokedex
    public Pokedex llenarPokedex(Pokedex pokedex) {
        return pokedex;
    }

    //Método para seleccionar el Pokemon que desea
    public void seleccionarPokemon() {

    }
}
