package modelo;

import javax.swing.JOptionPane;

public class Pokedex {

    private Pokemon[] listaPokemones;
    private int cantidadActualPokemones;
    private final int CAPACIDAD_MAXIMA = 4;

    public Pokedex() {
        this.listaPokemones = new Pokemon[CAPACIDAD_MAXIMA];
        this.cantidadActualPokemones = 0;
    }

    public Pokedex(Pokemon[] listaPokemones) {
        if (listaPokemones.length > 4) {
            JOptionPane.showMessageDialog(null, "No se pueden seleccionar más de " + CAPACIDAD_MAXIMA + "pokemones");
        }

        this.listaPokemones = listaPokemones;
        this.cantidadActualPokemones = 0;
    }

    public boolean estaVacia() {
        return this.cantidadActualPokemones == 0;
    }

    public boolean estaLlena() {
        return this.cantidadActualPokemones == CAPACIDAD_MAXIMA;
    }

    public boolean buscarSiExiste(Pokemon pokemon) {
        for (int i = 0; i < cantidadActualPokemones; i++) {
            if (listaPokemones[i].getNombre().equals(pokemon.getNombre())) {
                return true;
            }
        }

        return false;
    }

    public boolean agregarPokemon(Pokemon pokemon) {
        if (estaLlena()) {
            JOptionPane.showMessageDialog(null, "La Pokedex está llena, no se puede agregar más pokemones.");
        } else {
            if (buscarSiExiste(pokemon)) {
                JOptionPane.showMessageDialog(null, "No se puede insertar un pokemon repetido, debe seleccionar otro.");
            } else {
                this.listaPokemones[this.cantidadActualPokemones] = pokemon;
                this.cantidadActualPokemones++;

                return true;
            }
        }

        return false;
    }

    public void limpiarPokedex() {
        this.listaPokemones = new Pokemon[CAPACIDAD_MAXIMA];
        this.cantidadActualPokemones = 0;
    }
    
    public Pokemon obtenerSiguientePokemonConVida() {
        for (int i = 0; i < listaPokemones.length; i++) {
            Pokemon pokemon = listaPokemones[i];
            if (pokemon.estaConVida()) {
                return pokemon;
            }
        }
        
        return null;
    }
    
    public Pokemon cambiarPokemonConVida(Pokemon pokemonUsado) {
        for (int i = 0; i < listaPokemones.length; i++) {
            Pokemon pokemon = listaPokemones[i];
            
            // Buscar un pokemon con vida pero diferente al que se está usando.            
            if (pokemon.estaConVida() && !pokemonUsado.getNombre().equals(pokemon.getNombre())) {
                return pokemon;
            }
        }
        
        return null;
    }
    
    public void curarPokemones() {
        for (int i = 0; i < listaPokemones.length; i++) {
            Pokemon pokemon = listaPokemones[i];
            
            pokemon.setVida(pokemon.getVidaTotal());
        }
    }

    public Pokemon[] getListaPokemones() {
        return listaPokemones;
    }
}
