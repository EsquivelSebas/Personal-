package modelo;

public class Pokemon {

    private TipoPokemon tipo;
    private int Nivel;
    private int Evolucion; //se debe definir un numero para evolucionar a cada pokemon
    private String nombre;
    private TipoPokemon[] fuertesContra;
    private TipoPokemon[] debilesContra;
    private int vida;
    private int ataque;
    private int defensa;
    private int ataqueEspecial;
    private int defensaEspecial;
    private String imagen;
    private int vidaTotal;

    public Pokemon(String nombre, String imagen) {
        this.nombre = nombre;
        this.imagen = imagen;
    }

    public Pokemon(TipoPokemon tipo, int Nivel, int Evolucion, String Nombre, TipoPokemon[] fuertesContra, TipoPokemon[] debilesContra, int vida, int ataque, int defensa, int ataqueEspecial, int defensaEspecial) {
        this.tipo = tipo;
        this.Nivel = Nivel;
        this.Evolucion = Evolucion;
        this.nombre = Nombre;
        this.fuertesContra = fuertesContra;
        this.debilesContra = debilesContra;
        this.vida = vida;
        this.vidaTotal = vida;
        this.ataque = ataque;
        this.defensa = defensa;
        this.ataqueEspecial = ataqueEspecial;
        this.defensaEspecial = defensaEspecial;
    }

    public boolean estaConVida() {
        return this.vida > 0;
    }

    public int modificarVida(int ataqueRecibido) {
        if (ataqueRecibido != 0) {
            this.vida -= ataqueRecibido;
        }

        if (this.vida < 0) {
            this.vida = 0;

            // Mostrar mensaje por pantalla al jugador 
            System.out.println("Vida del pokemon en 0");
        }

        return this.vida;
    }

    public TipoPokemon getTipo() {
        return tipo;
    }

    public void setTipo(TipoPokemon tipo) {
        this.tipo = tipo;
    }

    public TipoPokemon[] getFuertesContra() {
        return fuertesContra;
    }

    public void setFuertesContra(TipoPokemon[] fuertesContra) {
        this.fuertesContra = fuertesContra;
    }

    public TipoPokemon[] getDebilesContra() {
        return debilesContra;
    }

    public void setDebilesContra(TipoPokemon[] debilesContra) {
        this.debilesContra = debilesContra;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }

    public int getAtaqueEspecial() {
        return ataqueEspecial;
    }

    public void setAtaqueEspecial(int ataqueEspecial) {
        this.ataqueEspecial = ataqueEspecial;
    }

    public int getDefensaEspecial() {
        return defensaEspecial;
    }

    public void setDefensaEspecial(int defensaEspecial) {
        this.defensaEspecial = defensaEspecial;
    }

    public int getNivel() {
        return Nivel;
    }

    public void setNivel(int Nivel) {
        this.Nivel = Nivel;
    }

    public int getEvolucion() {
        return Evolucion;
    }

    public void setEvolucion(int Evolucion) {
        this.Evolucion = Evolucion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public int getVidaTotal() {
        return vidaTotal;
    }

    public void setVidaTotal(int vidaTotal) {
        this.vidaTotal = vidaTotal;
    }

    @Override
    public String toString() {
        return "Pokemon:" + "tipo=" + "nombre=" + nombre + ", fuertesContra=" + ", vida=" + vida + ", ataque=" + ataque + ", defensa=" + defensa + ", ataqueEspecial=" + ataqueEspecial + ", defensaEspecial=" + defensaEspecial + ", vidaTotal=" + vidaTotal;
    }

}
