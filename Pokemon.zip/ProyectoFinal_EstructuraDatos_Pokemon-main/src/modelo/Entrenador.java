package modelo;

public class Entrenador {

    Pokedex pokedex;
    String nombre;

    public Entrenador(String nombre, Pokedex pokedex) {
        this.pokedex = pokedex;
        this.nombre = nombre;
    }

    public Pokedex getPokedex() {
        return pokedex;
    }

    public void setPokedex(Pokedex pokedex) {
        this.pokedex = pokedex;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
