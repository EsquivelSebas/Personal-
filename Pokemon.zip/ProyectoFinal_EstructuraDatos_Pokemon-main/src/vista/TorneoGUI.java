package vista;

import controlador.ControladorPrincipal;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import modelo.Batalla;
import modelo.Entrenador;
import modelo.Pokemon;

public class TorneoGUI extends javax.swing.JInternalFrame {

    ControladorPrincipal controladorPrincipal = ControladorPrincipal.obtenerInstanciaCompartida();
    Batalla batalla;
    Entrenador entrenador1;
    Entrenador entrenador2;
    Pokemon pokemonSeleccionadoEntrenador1;
    Pokemon pokemonSeleccionadoEntrenador2;
    String movimientosDuranteLaBatalla = "";
    
    /**
     * Creates new form TorneoGUI
     */
    public TorneoGUI() {
        initComponents();
        
        // Obtener datos de la batalla para configurar los labels de la interfaz con los 
        // nombres e imagenes de los pokemones.
        batalla = controladorPrincipal.obtenerSiguienteBatallaTorneo();
        entrenador1 = batalla.getEntrenador1();
        entrenador2 = batalla.getEntrenador2();
        
        batallaNumeroLabel.setText("Batalla #" + batalla.getNumeroBatalla());
        entrenador1Label1.setText(entrenador1.getNombre());
        entrenador2Label.setText(entrenador2.getNombre());
        
        pokemonSeleccionadoEntrenador1 = entrenador1.getPokedex().obtenerSiguientePokemonConVida();
        pokemonSeleccionadoEntrenador2 = entrenador2.getPokedex().obtenerSiguientePokemonConVida();
        
        mostrarTextoEnPantalla("La batalla ha iniciado " + pokemonSeleccionadoEntrenador1.getNombre() + " contra " + pokemonSeleccionadoEntrenador2.getNombre());
        
        refrescarPantalla();
    }
    
    private void mostrarTextoEnPantalla(String textoEnPantalla) {
        movimientosDuranteLaBatalla +=  textoEnPantalla + "\n";
        
        batallaAreaDeTexto.setText(movimientosDuranteLaBatalla);
    }
    
    private void pasarASiguienteBatalla() {
        batalla = controladorPrincipal.obtenerSiguienteBatallaTorneo();
        
        if (batalla == null) {
            mostrarTextoEnPantalla("El torneo ha finalizado");
            
            // Falta poner el ganador            
        }
        
        entrenador1 = batalla.getEntrenador1();
        entrenador2 = batalla.getEntrenador2();
        
        // Reiniciamos los textos de batalla y los nombres de los entrenadores que salen en la pantalla de la imagen del fondo.
        batallaNumeroLabel.setText("Batalla #" + batalla.getNumeroBatalla());
        entrenador1Label1.setText(entrenador1.getNombre());
        entrenador2Label.setText(entrenador2.getNombre());
        
        // Aqui curamos a los pokemones de los 2 entrenadores para que puedan volver a pelear.        
        entrenador1.getPokedex().curarPokemones();
        entrenador2.getPokedex().curarPokemones();
        
        pokemonSeleccionadoEntrenador1 = entrenador1.getPokedex().obtenerSiguientePokemonConVida();
        pokemonSeleccionadoEntrenador2 = entrenador2.getPokedex().obtenerSiguientePokemonConVida();
        
        mostrarTextoEnPantalla("La batalla ha iniciado " + pokemonSeleccionadoEntrenador1.getNombre() + " contra " + pokemonSeleccionadoEntrenador2.getNombre());
        
        refrescarPantalla();
    }
    
    private void refrescarPantalla() {
        // Este código lo buscamos en internet para poder cambiar las imagenes de los labels desde el código.
        // Con el getClass().getResource se obtiene la ubicación del paquete donde pusimos las imagenes y con el nombre del archivo se puede
        // crear el icono.
        pokemon1Label.setIcon(new ImageIcon(getClass().getResource(pokemonSeleccionadoEntrenador1.getImagen())));
        pokemon2Label.setIcon(new ImageIcon(getClass().getResource(pokemonSeleccionadoEntrenador2.getImagen())));
        
        // Conforme se avance en la pelea la idea es usar la imagen de "pokemon-disponible.png" al inicio y 
        // a medida que los van derrotando cambiar a "pokemon-derrotado.png" en los siguientes labels.
        ImageIcon pokemonDerrotado = new ImageIcon(getClass().getResource("/imagenes/pokemon-derrotado.png"));
        ImageIcon pokemonDisponible = new ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"));
        
        Pokemon[] listaPokemones1 = entrenador1.getPokedex().getListaPokemones();
        if (listaPokemones1[0].estaConVida()) {
            entrenador1pokemonBanca1Btn.setIcon(pokemonDisponible);
        } else {
            entrenador1pokemonBanca1Btn.setIcon(pokemonDerrotado);
        }
        
        if (listaPokemones1[1].estaConVida()) {
            entrenador1pokemonBanca2Btn.setIcon(pokemonDisponible);
        } else {
            entrenador1pokemonBanca2Btn.setIcon(pokemonDerrotado);
        }
        
        if (listaPokemones1[2].estaConVida()) {
            entrenador1pokemonBanca3Btn.setIcon(pokemonDisponible);
        } else {
            entrenador1pokemonBanca3Btn.setIcon(pokemonDerrotado);
        }
        
        if (listaPokemones1[3].estaConVida()) {
            entrenador1pokemonBanca4Btn.setIcon(pokemonDisponible);
        } else {
            entrenador1pokemonBanca4Btn.setIcon(pokemonDerrotado);
        }
        
        Pokemon[] listaPokemonesEntrenador2 = entrenador2.getPokedex().getListaPokemones();
        if (listaPokemonesEntrenador2[0].estaConVida()) {
            entrenador2pokemonBanca1Btn.setIcon(pokemonDisponible);
        } else {
            entrenador2pokemonBanca1Btn.setIcon(pokemonDerrotado);
        }
        
        if (listaPokemonesEntrenador2[1].estaConVida()) {
            entrenador2pokemonBanca2Btn.setIcon(pokemonDisponible);
        } else {
            entrenador2pokemonBanca2Btn.setIcon(pokemonDerrotado);
        }
        
        if (listaPokemonesEntrenador2[2].estaConVida()) {
            entrenador2pokemonBanca3Btn.setIcon(pokemonDisponible);
        } else {
            entrenador2pokemonBanca3Btn.setIcon(pokemonDerrotado);
        }
        
        if (listaPokemonesEntrenador2[3].estaConVida()) {
            entrenador2pokemonBanca4Btn.setIcon(pokemonDisponible);
        } else {
            entrenador2pokemonBanca4Btn.setIcon(pokemonDerrotado);
        }
        
        // Poner la vida en las barras de progreso de los pokemones.
        barraVidaPokemon1.setMinimum(0);
        barraVidaPokemon1.setMaximum(pokemonSeleccionadoEntrenador1.getVidaTotal());
        barraVidaPokemon1.setValue(pokemonSeleccionadoEntrenador1.getVida());
        
        barraVidaPokemon2.setMinimum(0);
        barraVidaPokemon2.setMaximum(pokemonSeleccionadoEntrenador2.getVidaTotal());
        barraVidaPokemon2.setValue(pokemonSeleccionadoEntrenador2.getVida());
        
        // Se valida la vida de cada pokemon para ver si hay que cambiarlo porque fue derrotado.        
        if (!pokemonSeleccionadoEntrenador1.estaConVida()) {
            mostrarTextoEnPantalla(pokemonSeleccionadoEntrenador1.getNombre() + " ha sido derrotado");
            
            pokemonSeleccionadoEntrenador1 = entrenador1.getPokedex().obtenerSiguientePokemonConVida();
            
            // Si no hay siguiente pokemon la batallá terminó
            if (pokemonSeleccionadoEntrenador1 == null) {
                mostrarTextoEnPantalla("La batalla ha finalizado.");
                
                
                // Si el usuario es el que pierde se deba reiniciar el torneo.
                controladorPrincipal.reiniciarTorneo();
                
                // Reiniciamos la batalla con la siguiente batalla
                pasarASiguienteBatalla();
                
                return;
            }
            
            mostrarTextoEnPantalla(pokemonSeleccionadoEntrenador1.getNombre() + " ha ingresado a la batalla.");
            pokemon1Label.setIcon(new ImageIcon(getClass().getResource(pokemonSeleccionadoEntrenador1.getImagen())));
            
            barraVidaPokemon1.setMinimum(0);
            barraVidaPokemon1.setMaximum(pokemonSeleccionadoEntrenador1.getVidaTotal());
            barraVidaPokemon1.setValue(pokemonSeleccionadoEntrenador1.getVida());
        }
        
        if (!pokemonSeleccionadoEntrenador2.estaConVida()) {
            mostrarTextoEnPantalla(pokemonSeleccionadoEntrenador2.getNombre() + " ha sido derrotado");
            
            // Cambiar de pokemon por el siguiente con vida            
            pokemonSeleccionadoEntrenador2 = entrenador2.getPokedex().obtenerSiguientePokemonConVida();
            
            // Si no hay siguiente pokemon la batallá terminó
            if (pokemonSeleccionadoEntrenador2 == null) {
                mostrarTextoEnPantalla("La batalla ha finalizado.");
                
                // Reiniciamos la batalla con la siguiente batalla
                pasarASiguienteBatalla();
                
                return;
            }
            
            
            mostrarTextoEnPantalla(pokemonSeleccionadoEntrenador2.getNombre() + " ha ingresado a la batalla.");
            pokemon2Label.setIcon(new ImageIcon(getClass().getResource(pokemonSeleccionadoEntrenador2.getImagen())));
            
            barraVidaPokemon2.setMinimum(0);
            barraVidaPokemon2.setMaximum(pokemonSeleccionadoEntrenador2.getVidaTotal());
            barraVidaPokemon2.setValue(pokemonSeleccionadoEntrenador2.getVida());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        vsLabel = new javax.swing.JLabel();
        batallaNumeroLabel = new javax.swing.JLabel();
        entrenador2Label = new javax.swing.JLabel();
        entrenador1Label1 = new javax.swing.JLabel();
        pokemon2Label = new javax.swing.JLabel();
        cambiarPokemonBtn = new javax.swing.JButton();
        pokemon2DefenderBtn = new javax.swing.JButton();
        pokemon1AtacarEspecialBtn = new javax.swing.JButton();
        pokemon1AtacarBtn1 = new javax.swing.JButton();
        pokemon1Label = new javax.swing.JLabel();
        pokemon2DefenderEspecialBtn1 = new javax.swing.JButton();
        entrenador2pokemonBanca2Btn = new javax.swing.JLabel();
        entrenador2pokemonBanca3Btn = new javax.swing.JLabel();
        entrenador2pokemonBanca4Btn = new javax.swing.JLabel();
        entrenador2pokemonBanca1Btn = new javax.swing.JLabel();
        entrenador1pokemonBanca2Btn = new javax.swing.JLabel();
        entrenador1pokemonBanca3Btn = new javax.swing.JLabel();
        entrenador1pokemonBanca4Btn = new javax.swing.JLabel();
        entrenador1pokemonBanca1Btn = new javax.swing.JLabel();
        barraVidaPokemon2 = new javax.swing.JProgressBar();
        barraVidaPokemon1 = new javax.swing.JProgressBar();
        batallaAreaTexto = new javax.swing.JScrollPane();
        batallaAreaDeTexto = new javax.swing.JTextArea();
        imagenFondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        vsLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        vsLabel.setForeground(new java.awt.Color(255, 255, 255));
        vsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        vsLabel.setText("vs");
        getContentPane().add(vsLabel);
        vsLabel.setBounds(290, 140, 220, 20);

        batallaNumeroLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        batallaNumeroLabel.setForeground(new java.awt.Color(255, 255, 255));
        batallaNumeroLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batallaNumeroLabel.setText("Batalla # 1");
        getContentPane().add(batallaNumeroLabel);
        batallaNumeroLabel.setBounds(290, 70, 220, 20);

        entrenador2Label.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        entrenador2Label.setForeground(new java.awt.Color(255, 255, 255));
        entrenador2Label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        entrenador2Label.setText("Entrenador 2");
        getContentPane().add(entrenador2Label);
        entrenador2Label.setBounds(290, 170, 220, 20);

        entrenador1Label1.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        entrenador1Label1.setForeground(new java.awt.Color(255, 255, 255));
        entrenador1Label1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        entrenador1Label1.setText("Entrenador 1");
        getContentPane().add(entrenador1Label1);
        entrenador1Label1.setBounds(290, 110, 220, 20);

        pokemon2Label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/growlithe.png"))); // NOI18N
        getContentPane().add(pokemon2Label);
        pokemon2Label.setBounds(510, 290, 100, 50);

        cambiarPokemonBtn.setText("Cambiar pokemon");
        cambiarPokemonBtn.setToolTipText("");
        cambiarPokemonBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cambiarPokemonBtnActionPerformed(evt);
            }
        });
        getContentPane().add(cambiarPokemonBtn);
        cambiarPokemonBtn.setBounds(10, 330, 140, 23);

        pokemon2DefenderBtn.setText("Defender");
        pokemon2DefenderBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pokemon2DefenderBtnActionPerformed(evt);
            }
        });
        getContentPane().add(pokemon2DefenderBtn);
        pokemon2DefenderBtn.setBounds(10, 240, 140, 23);

        pokemon1AtacarEspecialBtn.setText("Atacar Especial");
        pokemon1AtacarEspecialBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pokemon1AtacarEspecialBtnActionPerformed(evt);
            }
        });
        getContentPane().add(pokemon1AtacarEspecialBtn);
        pokemon1AtacarEspecialBtn.setBounds(10, 270, 140, 23);

        pokemon1AtacarBtn1.setText("Atacar");
        pokemon1AtacarBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pokemon1AtacarBtn1ActionPerformed(evt);
            }
        });
        getContentPane().add(pokemon1AtacarBtn1);
        pokemon1AtacarBtn1.setBounds(10, 210, 140, 23);

        pokemon1Label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/growlithe.png"))); // NOI18N
        getContentPane().add(pokemon1Label);
        pokemon1Label.setBounds(190, 290, 100, 50);

        pokemon2DefenderEspecialBtn1.setText("Defender Especial");
        pokemon2DefenderEspecialBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pokemon2DefenderEspecialBtn1ActionPerformed(evt);
            }
        });
        getContentPane().add(pokemon2DefenderEspecialBtn1);
        pokemon2DefenderEspecialBtn1.setBounds(10, 300, 140, 23);

        entrenador2pokemonBanca2Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"))); // NOI18N
        entrenador2pokemonBanca2Btn.setText("jLabel1");
        getContentPane().add(entrenador2pokemonBanca2Btn);
        entrenador2pokemonBanca2Btn.setBounds(630, 360, 40, 40);

        entrenador2pokemonBanca3Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"))); // NOI18N
        entrenador2pokemonBanca3Btn.setText("jLabel1");
        getContentPane().add(entrenador2pokemonBanca3Btn);
        entrenador2pokemonBanca3Btn.setBounds(680, 360, 40, 40);

        entrenador2pokemonBanca4Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"))); // NOI18N
        entrenador2pokemonBanca4Btn.setText("jLabel1");
        getContentPane().add(entrenador2pokemonBanca4Btn);
        entrenador2pokemonBanca4Btn.setBounds(730, 360, 40, 40);

        entrenador2pokemonBanca1Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"))); // NOI18N
        entrenador2pokemonBanca1Btn.setText("jLabel1");
        getContentPane().add(entrenador2pokemonBanca1Btn);
        entrenador2pokemonBanca1Btn.setBounds(580, 360, 40, 40);

        entrenador1pokemonBanca2Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"))); // NOI18N
        entrenador1pokemonBanca2Btn.setText("jLabel1");
        getContentPane().add(entrenador1pokemonBanca2Btn);
        entrenador1pokemonBanca2Btn.setBounds(60, 360, 40, 40);

        entrenador1pokemonBanca3Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"))); // NOI18N
        entrenador1pokemonBanca3Btn.setText("jLabel1");
        getContentPane().add(entrenador1pokemonBanca3Btn);
        entrenador1pokemonBanca3Btn.setBounds(110, 360, 40, 40);

        entrenador1pokemonBanca4Btn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        entrenador1pokemonBanca4Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"))); // NOI18N
        entrenador1pokemonBanca4Btn.setLabelFor(entrenador1pokemonBanca4Btn);
        entrenador1pokemonBanca4Btn.setText("dadadasd");
        getContentPane().add(entrenador1pokemonBanca4Btn);
        entrenador1pokemonBanca4Btn.setBounds(160, 360, 40, 40);

        entrenador1pokemonBanca1Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pokemon-disponible.png"))); // NOI18N
        entrenador1pokemonBanca1Btn.setText("jLabel1");
        getContentPane().add(entrenador1pokemonBanca1Btn);
        entrenador1pokemonBanca1Btn.setBounds(10, 360, 40, 40);

        barraVidaPokemon2.setBackground(new java.awt.Color(102, 255, 0));
        barraVidaPokemon2.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        barraVidaPokemon2.setForeground(new java.awt.Color(255, 255, 255));
        barraVidaPokemon2.setPreferredSize(new java.awt.Dimension(150, 20));
        barraVidaPokemon2.setStringPainted(true);
        getContentPane().add(barraVidaPokemon2);
        barraVidaPokemon2.setBounds(490, 250, 150, 20);

        barraVidaPokemon1.setBackground(new java.awt.Color(102, 255, 0));
        barraVidaPokemon1.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        barraVidaPokemon1.setForeground(new java.awt.Color(255, 255, 255));
        barraVidaPokemon1.setMaximumSize(new java.awt.Dimension(150, 20));
        barraVidaPokemon1.setMinimumSize(new java.awt.Dimension(150, 20));
        barraVidaPokemon1.setPreferredSize(new java.awt.Dimension(150, 20));
        barraVidaPokemon1.setStringPainted(true);
        getContentPane().add(barraVidaPokemon1);
        barraVidaPokemon1.setBounds(170, 250, 150, 20);

        batallaAreaTexto.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        batallaAreaTexto.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        batallaAreaDeTexto.setEditable(false);
        batallaAreaDeTexto.setBackground(new java.awt.Color(153, 153, 153));
        batallaAreaDeTexto.setColumns(10);
        batallaAreaDeTexto.setLineWrap(true);
        batallaAreaDeTexto.setRows(2);
        batallaAreaDeTexto.setTabSize(0);
        batallaAreaDeTexto.setText("Entrenador 1 ha usado Ataque Especial pero falló.");
        batallaAreaDeTexto.setWrapStyleWord(true);
        batallaAreaDeTexto.setEnabled(false);
        batallaAreaDeTexto.setMaximumSize(new java.awt.Dimension(190, 90));
        batallaAreaDeTexto.setMinimumSize(new java.awt.Dimension(190, 90));
        batallaAreaDeTexto.setOpaque(false);
        batallaAreaDeTexto.setRequestFocusEnabled(false);
        batallaAreaDeTexto.setSize(new java.awt.Dimension(230, 90));
        batallaAreaTexto.setViewportView(batallaAreaDeTexto);

        getContentPane().add(batallaAreaTexto);
        batallaAreaTexto.setBounds(280, 320, 240, 90);

        imagenFondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/estadio-800x450.jpg"))); // NOI18N
        getContentPane().add(imagenFondo);
        imagenFondo.setBounds(0, 0, 800, 450);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pokemon1AtacarEspecialBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pokemon1AtacarEspecialBtnActionPerformed
        int valorAtaque = batalla.atacarEspecial(pokemonSeleccionadoEntrenador1, pokemonSeleccionadoEntrenador2);
        
        if (valorAtaque == 0) {
            mostrarTextoEnPantalla(entrenador1.getNombre() + " ha usado Atacar Especial pero el ataque falló");
        } else {
            mostrarTextoEnPantalla(entrenador1.getNombre() + " ha usado Atacar Especial con un daño de " + valorAtaque);
        }

        // El siguiente turno es del jugador CPU.
        int valorAtaqueRival = batalla.realizarMovimientoAleatorioCPU(pokemonSeleccionadoEntrenador2, pokemonSeleccionadoEntrenador1, valorAtaque);
        if (valorAtaqueRival == 0) {
            mostrarTextoEnPantalla(entrenador2.getNombre() + " ha usado Atacar pero el ataque falló");
        } else {
            mostrarTextoEnPantalla(entrenador2.getNombre() + " ha usado Atacar con un daño de " + valorAtaqueRival);
        }
        
        refrescarPantalla();
        
        // Falta por hacer aqui que cuando los pokemones son derrotados se debe cambiar por el siguiente con vida.        
    }//GEN-LAST:event_pokemon1AtacarEspecialBtnActionPerformed

    private void cambiarPokemonBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cambiarPokemonBtnActionPerformed
        Pokemon nuevoPokemon = entrenador1.getPokedex().cambiarPokemonConVida(pokemonSeleccionadoEntrenador1);
        pokemonSeleccionadoEntrenador1 = nuevoPokemon;
        
        refrescarPantalla();
    }//GEN-LAST:event_cambiarPokemonBtnActionPerformed

    private void pokemon2DefenderBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pokemon2DefenderBtnActionPerformed
        // El siguiente turno es del jugador CPU.
        int valorAtaqueRival = batalla.realizarMovimientoAleatorioCPU(pokemonSeleccionadoEntrenador2, pokemonSeleccionadoEntrenador1, 0);
        if (valorAtaqueRival == 0) {
            mostrarTextoEnPantalla(entrenador2.getNombre() + " ha usado Atacar pero el ataque falló");
        } else {
            mostrarTextoEnPantalla(entrenador2.getNombre() + " ha usado Atacar con un daño de " + valorAtaqueRival);
        }
        
        refrescarPantalla();
    }//GEN-LAST:event_pokemon2DefenderBtnActionPerformed

    private void pokemon1AtacarBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pokemon1AtacarBtn1ActionPerformed
        // El turno es del jugador usuario
        int valorAtaque = batalla.atacar(pokemonSeleccionadoEntrenador1, pokemonSeleccionadoEntrenador2);        
        if (valorAtaque == 0) {
            mostrarTextoEnPantalla(entrenador1.getNombre() + " ha usado Atacar pero el ataque falló");
        } else {
            mostrarTextoEnPantalla(entrenador1.getNombre() + " ha usado Atacar con un daño de " + valorAtaque);
        }
        
        // El siguiente turno es del jugador CPU.
        int valorAtaqueRival = batalla.realizarMovimientoAleatorioCPU(pokemonSeleccionadoEntrenador2, pokemonSeleccionadoEntrenador1, valorAtaque);
        if (valorAtaqueRival == 0) {
            mostrarTextoEnPantalla(entrenador2.getNombre() + " ha usado Atacar pero el ataque falló");
        } else {
            mostrarTextoEnPantalla(entrenador2.getNombre() + " ha usado Atacar con un daño de " + valorAtaqueRival);
        }
        
        refrescarPantalla();
    }//GEN-LAST:event_pokemon1AtacarBtn1ActionPerformed

    private void pokemon2DefenderEspecialBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pokemon2DefenderEspecialBtn1ActionPerformed
        // El siguiente turno es del jugador CPU.
        int valorAtaqueRival = batalla.realizarMovimientoAleatorioCPU(pokemonSeleccionadoEntrenador2, pokemonSeleccionadoEntrenador1, 0);
        if (valorAtaqueRival == 0) {
            mostrarTextoEnPantalla(entrenador2.getNombre() + " ha usado Atacar pero el ataque falló");
        } else {
            mostrarTextoEnPantalla(entrenador2.getNombre() + " ha usado Atacar con un daño de " + valorAtaqueRival);
        }
        
        refrescarPantalla();
    }//GEN-LAST:event_pokemon2DefenderEspecialBtn1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TorneoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TorneoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TorneoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TorneoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TorneoGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar barraVidaPokemon1;
    private javax.swing.JProgressBar barraVidaPokemon2;
    private javax.swing.JTextArea batallaAreaDeTexto;
    private javax.swing.JScrollPane batallaAreaTexto;
    private javax.swing.JLabel batallaNumeroLabel;
    private javax.swing.JButton cambiarPokemonBtn;
    private javax.swing.JLabel entrenador1Label1;
    private javax.swing.JLabel entrenador1pokemonBanca1Btn;
    private javax.swing.JLabel entrenador1pokemonBanca2Btn;
    private javax.swing.JLabel entrenador1pokemonBanca3Btn;
    private javax.swing.JLabel entrenador1pokemonBanca4Btn;
    private javax.swing.JLabel entrenador2Label;
    private javax.swing.JLabel entrenador2pokemonBanca1Btn;
    private javax.swing.JLabel entrenador2pokemonBanca2Btn;
    private javax.swing.JLabel entrenador2pokemonBanca3Btn;
    private javax.swing.JLabel entrenador2pokemonBanca4Btn;
    private javax.swing.JLabel imagenFondo;
    private javax.swing.JButton pokemon1AtacarBtn1;
    private javax.swing.JButton pokemon1AtacarEspecialBtn;
    private javax.swing.JLabel pokemon1Label;
    private javax.swing.JButton pokemon2DefenderBtn;
    private javax.swing.JButton pokemon2DefenderEspecialBtn1;
    private javax.swing.JLabel pokemon2Label;
    private javax.swing.JLabel vsLabel;
    // End of variables declaration//GEN-END:variables
}
