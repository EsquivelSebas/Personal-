package controlador;

import vista.EstadioPokemonGUI;

public class Principal {

    public static void main(String[] args) {
        EstadioPokemonGUI ventanaPrincipal = new EstadioPokemonGUI();
        ventanaPrincipal.setVisible(true);        
    }
}
