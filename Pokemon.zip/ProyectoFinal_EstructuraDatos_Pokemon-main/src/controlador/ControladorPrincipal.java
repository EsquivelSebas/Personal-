package controlador;

import modelo.Batalla;
import modelo.Entrenador;
import modelo.Pokedex;
import modelo.Pokemon;
import modelo.PokemonAgua;
import modelo.PokemonFuego;
import modelo.PokemonNormal;

public class ControladorPrincipal {

    private static ControladorPrincipal instanciaCompartida;

    // Base de datos
    // Pokemones tipo normal
    PokemonNormal rattata = new PokemonNormal("Rattata", "/imagenes/rattata.png");
    PokemonNormal pidgey = new PokemonNormal("Pidgey", "/imagenes/pidgey.png");
    PokemonNormal meowth = new PokemonNormal("Meowth", "/imagenes/meowth.png");

    // Pokemones tipo agua
    PokemonAgua squirtle = new PokemonAgua("Squirtle", "/imagenes/squirtle.png");
    PokemonAgua psyduck = new PokemonAgua("Psyduck", "/imagenes/psyduck.png");
    PokemonAgua magikarp = new PokemonAgua("Magikarp", "/imagenes/magikarp.png");

    // Pokemones tipo agua
    PokemonFuego charmander = new PokemonFuego("Charmander", "/imagenes/charmander.png");
    PokemonFuego vulpix = new PokemonFuego("Vulpix", "/imagenes/vulpix.png");
    PokemonFuego growlithe = new PokemonFuego("Growlithe", "/imagenes/growlithe.png");

    Pokedex pokedexUsuario = new Pokedex();
    Entrenador usuario = new Entrenador("Ash", pokedexUsuario);

    Pokemon[] listaCpu1 = {rattata, squirtle, charmander, growlithe};
    Pokedex pokedexCpu1 = new Pokedex(listaCpu1);
    Entrenador cpu1 = new Entrenador("Brock", pokedexCpu1);

    Pokemon[] listaCpu2 = {pidgey, psyduck, vulpix, squirtle};
    Pokedex pokedexCpu2 = new Pokedex(listaCpu2);
    Entrenador cpu2 = new Entrenador("Misty", pokedexCpu2);

    Pokemon[] listaCpu3 = {meowth, vulpix, pidgey, charmander};
    Pokedex pokedexCpu3 = new Pokedex(listaCpu3);
    Entrenador cpu3 = new Entrenador("Gary", pokedexCpu3);

    int numeroBatallaActual = 0;

    public static ControladorPrincipal obtenerInstanciaCompartida() {
        if (instanciaCompartida == null) {
            instanciaCompartida = new ControladorPrincipal();
        }
        return instanciaCompartida;
    }
    
    public void reiniciarTorneo() {
        numeroBatallaActual = 0;
    }

    public Batalla obtenerSiguienteBatallaTorneo() {
        numeroBatallaActual++;
        
        switch (numeroBatallaActual) {
            case 1:
                Batalla batalla1 = new Batalla(usuario, cpu1, 1);
                return batalla1;
            case 2:
                Batalla batalla2 = new Batalla(usuario, cpu2, 2);
                return batalla2;
            case 3:
                Batalla batalla3 = new Batalla(usuario, cpu3, 3);
                return batalla3;
            default:
                break;
        }
        
        return null;
    }

    public PokemonNormal getRattata() {
        return rattata;
    }

    public PokemonNormal getPidgey() {
        return pidgey;
    }

    public PokemonNormal getMeowth() {
        return meowth;
    }

    public PokemonAgua getSquirtle() {
        return squirtle;
    }

    public PokemonAgua getPsyduck() {
        return psyduck;
    }

    public PokemonAgua getMagikarp() {
        return magikarp;
    }

    public PokemonFuego getCharmander() {
        return charmander;
    }

    public PokemonFuego getVulpix() {
        return vulpix;
    }

    public PokemonFuego getGrowlithe() {
        return growlithe;
    }

    public Pokedex getPokedexUsuario() {
        return pokedexUsuario;
    }

    public Entrenador getUsuario() {
        return usuario;
    }
}
