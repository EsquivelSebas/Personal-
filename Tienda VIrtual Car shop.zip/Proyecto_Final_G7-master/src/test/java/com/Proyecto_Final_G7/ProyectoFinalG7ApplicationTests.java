package com.Proyecto_Final_G7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalG7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
